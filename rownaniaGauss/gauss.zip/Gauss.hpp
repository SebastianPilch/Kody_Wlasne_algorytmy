#ifndef ROWNANIAGAUSS_GAUSS_HPP
#define ROWNANIAGAUSS_GAUSS_HPP
#include "LinkedList.hpp"
#include <cstdlib>
using namespace std;

float* Gauss_method(LinkedList &matrix_);

#endif //ROWNANIAGAUSS_GAUSS_HPP
